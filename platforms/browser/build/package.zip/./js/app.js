(function () {

	var module = angular.module('app', ['onsen']);

	module.controller('AppController', function ($scope, $timeout) {
		console.log("hello!");

		$scope.openMenu = function (m) {
                m.toggleMenu();
                m.setSwipeable(true);
                m.on('postclose', function (event) {
                    m.setSwipeable(true);
                });
        }

	});

	module.controller('HumidityController', function ($scope, $timeout) {
		console.log("HumidityController");
		if (document.getElementById("chart_div")) {
		  console.log('this record already exists');
		} else {
		  console.log("not here");
		}
	});

}());